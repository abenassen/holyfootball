from django.contrib import admin
from asta.models import *

admin.site.register(Allenatore)
admin.site.register(Calciatore)
admin.site.register(Offerta)
#admin.site.register(Acquisto)
admin.site.register(CalciatoreChiamato)


